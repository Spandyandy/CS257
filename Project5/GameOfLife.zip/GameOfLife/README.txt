Junghoo Kim
Project5


javac Conway.java
java Conway

click boxes you would like to select
If it turns yellow, it is selected
Change slider to change the speed from 1 second to 3 seconds
Press start button
Press stop button in order to stop or if you would like to change the speed




////////////////test1/////////////
*   *
*****


////////////////test2/////////////
***


////////////////test3/////////////
*
*
*



////////////////test4/////////////
 *
  *
***



////////////////test5/////////////

********************


Known Bugs: As I told you earlier today, living cell set size grows expotentially, and eventually lags the program.


javadoc url
hive.sewanee.edu/kimj0/CS257/Project5
