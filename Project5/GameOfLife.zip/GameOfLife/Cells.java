/**
 * Cells - implements the Cell model for Conway's Game Of Life
 * Junghoo Kim (Andy)
 * Conway Game Of Life program using hashSet  
 *   
 *   
 */
import java.awt.*;
import objectdraw.*;
import java.util.*;

public class Cells extends ActiveObject {
    private static int DELAY;
    private int x = 0;
    private int y = 0;
    private DrawingCanvas canvas;
    private boolean alive = true;
    private boolean stopped = false;
    private FilledRect[][] gameBoard;
    private CoordinateSet cell;
    private CoordinateSet nbs = new CoordinateSet();
    private Iterator<Coordinate> itr;

    /**
     * constructor
     * @param int delay, CoordinateSet cSet, int numX, int numY, FilledRect[][] board, DrawingCanvas dc
     * @precondition All variables are initialized beforehands, and all of them has to be valid.
     * @postcondition set up variables for Cells class
     */
    public Cells(int delay, CoordinateSet cSet, int numX, int numY, FilledRect[][] board, DrawingCanvas dc) {
        cell = cSet;
        gameBoard = board;
        canvas = dc;
	    x = numX;
	    y = numY;
        DELAY = delay;
        start();
    }

    /**
     *  run() 
     *
     * @precondition CoordinateSet must not include the edges or corner Coordinates
     * @postcondition add and remove Coordinate from CoordinateSet in order to make the game going.
     */
    public void run() {
        int[] liveNeighbors;
        Coordinate[] arr;
        Coordinate cord, cord2;

        while (stopped == false) {
        	nbs.clear();

        	itr = cell.iterator();
       		for(int n = 0; n < cell.size(); n++){
                cord = itr.next();
        	    int i = cord.getX();
        	    int j = cord.getY();
        	    nbs.add(cord); //adding living cell
                nbs.add(new Coordinate(i-1,j-1));
                nbs.add(new Coordinate(i,j-1));
                nbs.add(new Coordinate(i+1,j-1));
                nbs.add(new Coordinate(i-1,j));
                nbs.add(new Coordinate(i+1,j));
                nbs.add(new Coordinate(i-1,j+1));
                nbs.add(new Coordinate(i,j+1));
                nbs.add(new Coordinate(i+1,j+1));
       		}

            itr = nbs.iterator();
            liveNeighbors = new int[nbs.size()];
            for(int i = 0; i < nbs.size(); i++){
                cord = itr.next();
                liveNeighbors[i]=countNeighbors(cord);
            }

            itr = nbs.iterator();
            for(int i = 0; i < nbs.size(); i++){
                cord = itr.next();
                cord2 = new Coordinate(cord.getX(), cord.getY());
                if (!cell.contains(cord)){
                	if(liveNeighbors[i]==3){
                        cell.add(cord2);
                		gameBoard[cord.getX()][cord.getY()].setColor(Color.YELLOW);
                	}
                }
                else{
                	if(liveNeighbors[i] < 2 || liveNeighbors[i] > 3){
                        cell.remove(cord2);
                        gameBoard[cord.getX()][cord.getY()].setColor(Color.PINK);
                    }
                }
            }
            pause(DELAY);
        }
    }

    /**
     *  countNeighbors 
     *
     * @param Coordinate livingcell
     * @precondition livingcell must not be on the edge or corners
     * @postcondition returns how many alive coordinates among the neighbors of a livingcell
     */
    private int countNeighbors(Coordinate livingcell){
    	int count = 0;
    	int i = livingcell.getX();
        int j = livingcell.getY();
        if(gameBoard[i-1][j-1].getColor()==Color.YELLOW) count++;
        if(gameBoard[i][j-1].getColor()==Color.YELLOW) count++;
        if(gameBoard[i+1][j-1].getColor()==Color.YELLOW) count++;
        if(gameBoard[i-1][j].getColor()==Color.YELLOW) count++;
        if(gameBoard[i+1][j].getColor()==Color.YELLOW) count++;
        if(gameBoard[i-1][j+1].getColor()==Color.YELLOW) count++;
        if(gameBoard[i][j+1].getColor()==Color.YELLOW) count++;
        if(gameBoard[i+1][j+1].getColor()==Color.YELLOW) count++;
        return count;
    }

    /**
     *  reset() 
     *
     * @postcondition clear both living cell set and non-living cell set. Stop the game.
     */
    public void reset() {
       stopped = true;
       cell.clear();
       nbs.clear();
    }
}
