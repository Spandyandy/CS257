/**
 * CoordinateSet.java - implements the Cell model for Conway's Game Of Life
 * Junghoo Kim (Andy)
 * Conway Game Of Life program using hashSet  
 *   
 *   
 */

import java.awt.*;
import objectdraw.*;
import java.util.*;
public class CoordinateSet{ 
	Set<Coordinate> hset;

	/**
     * constructor
     *
     * @precondition hset is a Set<Coordinate> type, java.util is imported
     * @postcondition Construct hset as a HashSet<Coordinate> 
     */
	public CoordinateSet(){
		hset = new HashSet<Coordinate>();
	}

	/**
     * add(Coordinate c)
     * @param Coordinate c
     * @precondition c must be valid and not set does not contain c.
     * @postcondition Adds Coordinate c into set.
     */
	public void add(Coordinate c){
		if(!this.contains(c)){
			hset.add(c);
		}
	}

	/**
     * size()
     * 
     * 
     * @postcondition Returns size of set.
     */
	public int size(){return hset.size();}

	/**
     * contains(Coordinate c)
     * @param Coordinate c
     * @precondition c must be valid
     * @postcondition Returns whether set contains Coordinate c
     */
	public boolean contains(Coordinate c){return hset.contains(c);}

	/**
     * remove(Coordinate c)
     * @param Coordinate c
     * @precondition c must be valid
     * @postcondition Removes the specified element from this set if it is present and returns it.
     */
	public boolean remove (Coordinate c){return hset.remove(c);}

	/**
     * isEmpty()
     * 
     * 
     * @postcondition Returns true if set is empty.
     */
	public boolean isEmpty(){return hset.isEmpty();}

	/**
     * clear()
     * 
     * 
     * @postcondition Removes all of the elements from this set. The set will be empty after this call returns.
     */
	public void clear(){hset.clear();}


	/**
     * iterator()
     * 
     * @precondition set is not empty
     * @postcondition Returns an iterator over the elements in this set. The elements are returned in no particular order.
     */
	public Iterator<Coordinate> iterator(){return hset.iterator();}
}