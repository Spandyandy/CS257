/**
 * Conway - an implementation of Conway's Game Of Life
 * Junghoo Kim (Andy)
 * Conway Game Of Life program using hashSet  
 *   
 *   
 */

import objectdraw.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Conway extends WindowController implements ActionListener {
    private static int DELAY = 2000;
    private static final int x=50;
    private static final int y=50;
    private boolean started = false;
    private FilledRect[][] gameBoard = new FilledRect[x][y];
    private FramedRect[][] gameBoardOutline = new FramedRect[x][y];

    private JButton startButton, stopButton;
    private JSlider slider;
    private JPanel startControl;

    private Cells configuration;

    private CoordinateSet cs = new CoordinateSet();;
    private Coordinate c;

    public static void main (String[] args) {
        new Conway().startController(850, 850);
    }

    public void actionPerformed(ActionEvent evt) {
        if (evt.getSource() == startButton) {
            StartGame();
        } else if (evt.getSource() == stopButton) {
            StopGame();
        }
    }

    public void begin(){
        startButton = new JButton ("START");
        startButton.addActionListener(this);
        slider = new JSlider(1, 3);
        slider.addChangeListener(e-> sliderChanged());
        slider.setMajorTickSpacing(1);
        slider.setPaintTicks(true);
        slider.setPaintLabels(true);
        stopButton = new JButton ("STOP");
        stopButton.addActionListener(this);


        startControl = new JPanel();
        startControl.add(startButton);
        startControl.add(stopButton);
        startControl.add(slider);

        Container contentPane = getContentPane();
        contentPane.add(startControl, BorderLayout.SOUTH);
        contentPane.validate();

        for(int i=0; i<x; i++) {
            for(int j=0; j<y; j++){
                gameBoard[i][j] = new FilledRect(i*15, j*15, 15,15,canvas);
                gameBoard[i][j].setColor(Color.PINK);
                gameBoardOutline[i][j] = new FramedRect(i*15, j*15, 15,15,canvas);
                gameBoardOutline[i][j].setColor(Color.BLACK);
            }
        }
    }

    /**
     * 
     * @param Location point 
     * @precondition gameBoard within the array size. 
     * @postcondition changes the color of square to Yellow. And adds coordinate to coordinateset
     */
    public void onMouseClick(Location point) {
        for(int i=0; i<x; i++) {
            for(int j=0; j<y; j++){
                if(gameBoard[i][j].contains(point)){
                    gameBoard[i][j].setColor(Color.YELLOW);
                    cs.add(new Coordinate(i, j));
                }
            }
        }
    }
    /**
     * sliderChanged
     *  
     * @precondition if game is already started 
     * @postcondition show error message
     */
    public void sliderChanged()
		{
			if(started)
			JOptionPane.showMessageDialog(slider,
			   "No No No, change it before starting! Now It's lagging. Thanks.");
		}

    /**
     * StartGame()
     *  
     * @precondition every variables need to be valid and matches the type 
     * @postcondition set boolean type started to true and hands variables to Cells class
     */
    public void StartGame(){
    	DELAY = slider.getValue()*1000;
        configuration = new Cells(DELAY, cs, x, y, gameBoard, canvas);
    	started = true;
    }

    /**
     * StopGame()
     *  
     * @postcondition stop the game, set started to false. turn everything to original.
     */
    public void StopGame(){
    	started = false;
        for(int i=0; i<x; i++) {
            for(int j=0; j<y; j++){
                gameBoard[i][j] = new FilledRect(i*15, j*15, 15,15,canvas);
                gameBoard[i][j].setColor(Color.PINK);
                gameBoardOutline[i][j] = new FramedRect(i*15, j*15, 15,15,canvas);
                gameBoardOutline[i][j].setColor(Color.BLACK);
            }
        }
        configuration.reset();
    }
}

                        

