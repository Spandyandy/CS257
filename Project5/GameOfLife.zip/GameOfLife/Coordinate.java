/**
 * Coordinate.java - implements the Cell model for Conway's Game Of Life
 * Junghoo Kim (Andy)
 * Conway Game Of Life program using hashSet  
 *   
 *   
 */
public class Coordinate{
	int xLoc, yLoc;
	/**
     * constructor with no parameter
     */
	public Coordinate(){};

	/**
     * constructor
     * @param int x, int y
     * @precondition valid int type x and y
     * @postcondition constructor - set coordinate with x Location and y Location 
     */
	public Coordinate(int x, int y){
		xLoc = x;
		yLoc = y;
	}
	
	/**
     * getX()
     * @precondition xLoc must be valid integer
     * @postcondition returns x Location
     */
	public int getX(){return xLoc;}
	/**
     * getY()
     * @precondition yLoc must be valid integer
     * @postcondition returns y Location
     */
	public int getY(){return yLoc;}

	/**
	 *	isNeighborOf
	 *  @param Coordinate c2
	 *	@precondition c2 must be valid coordinate int type
	 *	@postcondition returns true if c2 is in neighbor, false otherwise
	 *
	 */
	public boolean isNeighborOf(Coordinate c2){
		if(!this.equals(c2)){
			if(this.getX()-1==c2.getX() || this.getX()==c2.getX()|| this.getX()-1==c2.getX()){
				if(this.getY()-1==c2.getY() || this.getY()==c2.getY()|| this.getY()-1==c2.getY()){
					return true;
				}
			}
		}
		return false;
	}

	/**
	 *	equals
	 *  @param Coordinate c2
	 *	@precondition c2 must be valid coordinate int type
	 *	@postcondition returns true if this is equal to c2, false otherwise
	 *
	 */
	public boolean equals(Coordinate c2){
		return (this.getX()==c2.getX() && this.getY()==c2.getY());
	}
}